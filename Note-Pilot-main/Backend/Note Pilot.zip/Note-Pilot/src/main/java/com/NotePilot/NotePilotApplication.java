package com.NotePilot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotePilotApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotePilotApplication.class, args);
	}

}
